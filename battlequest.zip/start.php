<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/dungeon.css" rel="stylesheet">
	<link href="css/sprites.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>
	<body>

	<?php
	
	function get_from_db($db, $key, $value){
		/*
		$SQL_obj = "SELECT * FROM ".$db;
		if (isset($key) && isset($value)){
			$SQL_obj .= " WHERE ".$key."=".$value;
		}
		*/
		
		$json_object = file_get_contents('./json/'.$db.'.json');
		$result_object = json_decode($json_object,true);
		return dbfilter($result_object, $key, $value);
		
	}
		
	function dbfilter($arr, $key, $value) {
		$result = array();
		if (empty($key) || empty($value)){
			return $arr;
		}
		foreach ($arr as $obj){
			if ($obj[$key] === $value){
				array_push($result, $obj);
			}
		}
		if (count($result) == 0){
			return array();
		} else {
			return $result;
		}
	}
		
	function sort_by_key($arr, $field){
		$names = array();
		foreach ($arr as $key => $row){
			$names[$key] = $row[$field];
		}
		array_multisort($names, SORT_ASC, $arr);
		return $arr;
							
	}
		
    if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, '', time()-1000);
        setcookie($name, '', time()-1000, '/');
		}
	}
	
	echo '<div id="dungeon-picker" class="bordered-window opacity80">';
		$result_dungeon = get_from_db('dungeon','share','1');
		
		echo '	<table id="dungeon-table">';
		echo '		<tr><td>Name</td><td>Description</td><td>Number of Characters</td><td>Tag Dungeon</td><td></td></tr>';
			
		foreach ($result_dungeon as $db_dungeon) {
			$result_floor = get_from_db('floor','dungeon_id',$db_dungeon['ID']);
			$db_floor = dbfilter($result_floor,'starting_floor','1')[0];
			
			echo '	<tr>';
			echo '		<td>'.$db_dungeon['name'].'</td>';
			echo '		<td><div class="list-description">'.$db_dungeon['description'].'</div></td>';
			echo '		<td>'.$db_dungeon['total_characters'].'</td>';
			if ($db_dungeon['tag']){
				echo '	<td><div class="glyphicon glyphicon-ok"></div></td>';
			} else {
				echo '	<td><div class="glyphicon glyphicon-remove"></div></td>';
			}
			echo '		<td><a class="start-button play-'.$db_dungeon['ID'].'" onclick="playDungeon('.$db_dungeon['ID'].','.$db_floor['ID'].','.$db_dungeon['total_characters'].')">Play Dungeon</a></td>';
			echo '	</tr>';
		}
		echo '	</table>';
	echo '</div>';
	
	
	echo '<div id="player-picker" class="bordered-window opacity80">';
	echo '	<h1>SELECT YOUR FIGHTER</h1>';
	echo '	<div class="current-selections"></div>';
	echo '	<div id="hero-filters">';
	echo '		<h3>Filters</h3>';
	echo '		<div class="filter-name">';
	echo '			Search: <input class="name-input" type="text"></input>';
	echo '		</div>';
	echo '		<div class="filter-checkboxes">';
	echo '		<span class="filter-set">';
	echo '			<input type="checkbox" value="war" checked>War of Indines</input><br />';
	echo '			<input type="checkbox" value="devastation" checked>Devastation of Indines</input><br />';
	echo '			<input type="checkbox" value="fate" checked>Fate of Indines</input><br />';
	echo '			<input type="checkbox" value="promo" checked>Promotional Materials</input><br />';
	echo '		</span>';
	echo '		<span class="filter-flight">';
	echo '			<input type="checkbox" value="novice" checked>Novice</input><br />';
	echo '			<input type="checkbox" value="beginner" checked>Beginner</input><br />';
	echo '			<input type="checkbox" value="intermediate" checked>Intermediate</input><br />';
	echo '			<input type="checkbox" value="advanced" checked>Advanced</input><br />';
	echo '			<input type="checkbox" value="master" checked>Master</input><br />';
	echo '		</span>';
	echo '		</div>';
	echo '	</div>';
	
	echo '  <br /><div class="btn btn-primary">NEXT</div>';
	
	echo '	<div class="fighter-select">';
	
	$result_hero = get_from_db('hero','','');
	$result_hero = sort_by_key($result_hero,'name');
	
	foreach ($result_hero as $db_hero) {
		echo '	<div class="select-panel">';
		echo '		<div class="select-portrait '.$db_hero['pClass'].'"></div>';
		echo '		<div class="hero-name">'.$db_hero['name'].'</div>';
		echo '		<div class="hero-set hidden">'.$db_hero['game'].'</div>';
		echo '		<div class="hero-flight hidden">'.$db_hero['flight'].'</div>';
		echo '	</div>';
	}
	
	echo '	</div>';
	echo '</div>';
	?>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/jquery-ui.js"></script>
	
	<script src="js/dungeon.js"></script>
	<script src="js/newgame.js"></script>
    
  </body>
</html>
